def initialize(arg1, arg2, ...):
	""" high level description of what the function does
	param arg1: description of argument 1
	param arg2: description of argument 2
	...
	return: description of what the function returns
	"""
	
	all_weights = ...
	all_biases = ...
	
	
	return all_weights, all_biases

def compute_cost(arg1, arg2, ...):
	""" high level description of what the function does
	param arg1: description of argument 1
	param arg2: description of argument 2
	... 
	return: description of what the function returns
	"""
	
	L = 
	
	return L